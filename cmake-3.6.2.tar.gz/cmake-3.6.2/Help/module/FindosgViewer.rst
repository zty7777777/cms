.. cmake-module:: ../../Modules/FindosgViewer.cmake
