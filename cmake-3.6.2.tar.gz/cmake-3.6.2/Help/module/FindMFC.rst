.. cmake-module:: ../../Modules/FindMFC.cmake
