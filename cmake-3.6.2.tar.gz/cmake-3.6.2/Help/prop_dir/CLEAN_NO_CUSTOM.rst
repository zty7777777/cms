CLEAN_NO_CUSTOM
---------------

Set to true to tell :ref:`Makefile Generators` not to remove the outputs of
custom commands for this directory during the ``make clean`` operation.
This is ignored on other generators because it is not possible to implement.
